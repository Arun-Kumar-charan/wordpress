<!-- <section class="banner-wrap">

      <div class="inner-banner-content">

        <div class="banner-item">
          <div class="banner-img">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/products.jpg" alt="">
          </div>
          <div class="container banner-content">
            <div class="banner-content-wrapper">
              <h1>Products</h1>
            </div>
          </div>
        </div>
       
      </div>
</section>
<main class="main-section">
  <section class="product-listing-sec common-padd">
    <div class="container">
      <div class="custom-heading text-center">
        <div class="hdng-top">
          <p>products</p>
        </div>
        <h2>Our products</h2>
      </div>
</div> -->